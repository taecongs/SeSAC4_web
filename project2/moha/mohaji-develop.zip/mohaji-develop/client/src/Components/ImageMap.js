import React, {} from "react";


const ImageMap = () => {
    return(
        <div>

        </div>
    );
}

export default ImageMap;