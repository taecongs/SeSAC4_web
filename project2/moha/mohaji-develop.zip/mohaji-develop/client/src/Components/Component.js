const Component = () => {
    return (
        <div>Component</div>
    )
}

export default Component;